//
//  ViewController.h
//  wanderBoard
//
//  Created by Stephen Moraco on 12/05/21.
//  Copyright (c) 2012 Iron Sheep Productions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    
}

@property (weak, nonatomic) IBOutlet UIButton *btnReverse;

- (IBAction)onReversePress:(id)sender;

@end
